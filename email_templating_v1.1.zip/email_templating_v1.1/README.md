Marketing Email Generator
================================
*View the [source of this content](https://github.com/prefectionist/email_templating).*

This is a purpose built program for generating complete HTML for email marketing purposes.  It operates around a set of modules that are referenced by an Excel 'source file' for inclusion and content tags.  Finished content is then FTP to QA and Production servers.

Release Notes
------------
version 1.1 - 8.13.2013
*Modified modules: 2Offer, 3Offer, 4Offer, and sotm.
*Added usage guide to software package.

version 1.0 - 8.6.2013
*Initial working release.

<pre>
             ,-. 
    ,     ,-.   ,-. 
   / \   (   )-(   ) 
   \ |  ,.>-(   )-< 
    \|,' (   )-(   ) 
     Y ___`-'   `-' 
     |/__/   `-' 
     | 
     | 
     |    -sl- 
  ___|_____________ 
</pre>